VERSION = (0, 1, 8)

__version__ = '.'.join([str(n) for n in VERSION])
